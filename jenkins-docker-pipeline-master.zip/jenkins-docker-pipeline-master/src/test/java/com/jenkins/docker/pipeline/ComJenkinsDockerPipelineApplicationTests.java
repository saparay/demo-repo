package com.jenkins.docker.pipeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComJenkinsDockerPipelineApplicationTests {

	@Test
	void contextLoads() {
	}

}
